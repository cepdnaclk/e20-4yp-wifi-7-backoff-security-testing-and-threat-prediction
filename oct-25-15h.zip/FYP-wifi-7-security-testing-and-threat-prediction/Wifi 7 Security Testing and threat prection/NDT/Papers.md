[[FYP-wifi-7-security-testing-and-threat-prediction/Wifi 7 Security Testing and threat prection/NDT/NDT_Summeries/1_A Functional Framework for Network Digital Twins/1_NDT_Main]]

[[FYP-wifi-7-security-testing-and-threat-prediction/Wifi 7 Security Testing and threat prection/NDT/NDT_Summeries/2_Architectural Design for Digital Twin Networks/2_Main]]

[[FYP-wifi-7-security-testing-and-threat-prediction/Wifi 7 Security Testing and threat prection/NDT/NDT_Summeries/3_Building a Digital Twin for network optimization using Graph Neural Networks/3_Main]]

[[FYP-wifi-7-security-testing-and-threat-prediction/Wifi 7 Security Testing and threat prection/NDT/NDT_Summeries/4_Building_a_Digital_Twin_Network_of_SDN_Using_Knowledge_Graphs/4_Main]]

[[FYP-wifi-7-security-testing-and-threat-prediction/Wifi 7 Security Testing and threat prection/NDT/NDT_Summeries/5_CONTAINERLAB AS A TOOL FOR NETWORK MODELING AND SIMULATION BASED ON CONTAINERIZATION/5_Main]]

[[FYP-wifi-7-security-testing-and-threat-prediction/Wifi 7 Security Testing and threat prection/NDT/NDT_Summeries/6_Design & Evaluation of an NDN-Based Network for Distributed Digital Twins/6_Main]]

[[FYP-wifi-7-security-testing-and-threat-prediction/Wifi 7 Security Testing and threat prection/NDT/NDT_Summeries/7_Digital twin of wireless systems Overview taxonomy challenges and opportunities/7_Main]]

[[FYP-wifi-7-security-testing-and-threat-prediction/Wifi 7 Security Testing and threat prection/NDT/NDT_Summeries/8_Machine learning based propagation loss module/8_Main]]

[[FYP-wifi-7-security-testing-and-threat-prediction/Wifi 7 Security Testing and threat prection/NDT/NDT_Summeries/8_Machine learning based propagation loss module for enabling digital twins of wireless networks in ns-3/8_Main]]


[[FYP-wifi-7-security-testing-and-threat-prediction/Wifi 7 Security Testing and threat prection/NDT/NDT_Summeries/9_Network Digital Twin Toward Networking/9_Main]]

[[FYP-wifi-7-security-testing-and-threat-prediction/Wifi 7 Security Testing and threat prection/NDT/NDT_Summeries/10_Network Digital Twins A Systematic Review/10_Main]]
