[[Summary Design & Evaluation of an NDN-Based Network for Distributed Digital Twins 1]]
[[Concepts you can lift straight into your Wi-Fi 7 threat-prediction twin]]
[[What is NDN - Named Data Networking]]



![[6_Design and Evaluation of an NDN-Based Network for Distributed Digital Twins.pdf]]