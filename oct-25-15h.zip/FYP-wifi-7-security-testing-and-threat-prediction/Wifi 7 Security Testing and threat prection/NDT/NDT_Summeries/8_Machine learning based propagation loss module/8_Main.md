[[Summary Machine learning based propagation loss module for enabling digital twins of wireless networks in ns-3tled]]
[[Take from this paper for your Wi-Fi 7 DT]]


![[8_Machine learning based propagation loss module for enabling digital twins of wireless networks in ns-3.pdf]]