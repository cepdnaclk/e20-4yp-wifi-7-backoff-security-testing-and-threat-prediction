[[Summary what the paper is and why it matters]]
[[What you can learn (and reuse)]]
[[How the paper applies With Ns-3+netbox+containerlab]]






![[2_Architectural Design for Digital Twin Networks.pdf]]