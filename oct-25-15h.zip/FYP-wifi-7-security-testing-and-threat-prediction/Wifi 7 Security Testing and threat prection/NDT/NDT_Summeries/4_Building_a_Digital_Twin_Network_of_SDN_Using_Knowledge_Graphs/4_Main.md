[[Summary DTN with Knowledge Graph]]



![[4_Building_a_Digital_Twin_Network_of_SDN_Using_Knowledge_Graphs.pdf]]