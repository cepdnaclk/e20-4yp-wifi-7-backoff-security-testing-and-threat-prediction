[[Summary Building a Digital Twin for network optimization using Graph Neural Networks]]




![[3_Building a Digital Twin for network optimization using Graph Neural Networks.pdf]]