Translation of the paper : [[FYP-wifi-7-security-testing-and-threat-prediction/Wifi 7 Security Testing and threat prection/NDT/NDT_Papers/SomeWhatImportant/5_CONTAINERLAB AS A TOOL FOR NETWORK MODELING AND SIMULATION BASED ON CONTAINERIZATION]]

[[Summary Containerlab as a lightweight way to model and simulate networks]]




![[5_CONTAINERLAB ЯК ІНСТУРМЕНТ.pdf]]