Breaking Wi-Fi Through Frame Aggregation and Fragmentation" details a set of severe vulnerabilities, known as FragAttacks (Fragmentation and Aggregation Attacks), that undermine the security of Wi-Fi networks.

The Goal: The ultimate objective of these attacks is to enable an adversary to forge encrypted frames, which in turn facilitates the exfiltration of sensitive data.