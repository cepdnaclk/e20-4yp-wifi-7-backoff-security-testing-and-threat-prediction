[[Cache-enabled Wi-Fi offloading]]
[[LDOS Attack]]
[[Security implications & defenses]]
