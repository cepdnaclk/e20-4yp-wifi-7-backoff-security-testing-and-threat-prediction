[[Artificial Neural Network (ANN) Classifier]]
[[Comparison]]
[[Error-Based Monitoring]]
[[Hidden Markov Model (HMM) Classifier]]
