


![[Pasted image 20251017181922.png]]
