[[STR and Non STR]]

[[Backoff in Wi-Fi]]
[[Sync FT]]

[[Sync PL]]

Whenever there are Sync FT and Sync PL, there is a more likely chance that Sync FT gets more chance for transmission since it can use the BO time to allow more 

[[Contention Window]]
[[Puncturing]]
[[95th percentile delay]]
[[Clear channel assessment]]

[[STR MLMR]]
[[APC]]
[[Radio link allocation]]
[[Intelligent AP-STAs]]
[[Multi Arm Bandit]]
[[Multi-Link EDCA Optimization]]
[[Markov Chain]]


[[arbitration inter-frame spacing (AIFS)]]
[[Packet Steering]]
[[Early steering and late steering and combined steering]]
[[Hybrid Automatic Repeat Request]]
[[FDR-Based Optimization (Frame Delivery Ratio)]]
[[BSS (Basic Service Set)]]
[[Time-Sensitive Networking (TSN)]]
[[Received Signal Strength Indicator (RSSI)]]
[[Quality of Experience (QoE)]]
[[Listen Before Talk (LBT)]]
[[Distributed Coordination Function (DCF)]]
[[QUC (QoS Unit Control)]]

[[4096-QAM Modulation]]
[[Frame Aggregation]]
[[Qos in MLOs and Wifi 7]]
[[Quality of Experience (QoE)]]