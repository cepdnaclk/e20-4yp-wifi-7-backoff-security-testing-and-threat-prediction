[[Exploitation Of MAB]][[RF power leakages]]
[[Cross link inteference in MLO]]


There exists Wi-Fi technologies that allow a device to connect to a single link and is capable

of switching among 2.4GHz, 5GHz and 6GHz bands. However, such Wi-Fi devices typically have

a switching overhead or delay of up to 100ms. Therefore, MLO is highly desirable for real-time

applications like video calls, wireless VR headsets and other things.

[[Collition Probability]]
[[Naive Splitting]]
[[Exploitation Of MAB]]
