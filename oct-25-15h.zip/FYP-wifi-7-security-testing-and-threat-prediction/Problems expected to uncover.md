1. Backoff Manipulation for continuous  asynchronous mode in NON STR[[Backoff Overflow]]
2. Cross link interference by simulating a Legacy device to block primary link[[Cross link inteference in MLO]]
3. Increasing collision probability by backoff and countdown
4. Frame Aggregation & Striping Risks[[Frame Aggregation]]
5. Multi-Link Association Hijacking
6. Naive Splitting and causing out of order packets - Possible in nature and principle[[Markov Chain]]
7. Exploitation of Multi arm bandit algorithms[[Multi Arm Bandit]]
8. Packet Splitting challenges exploitation[[Packet Steering]]
9. Collision Exploitations[[Collition Probability]]
10. Packet Allocation Exploitation [[Early steering and late steering and combined steering]]
11. HARQ Vulnerability Accessing [[High-level HARQ vulnerability categories (non-actionable)]]
12. beam hijacking or spoofed CSI feedback[[beam hijacking or spoofed CSI feedback]]
13. 